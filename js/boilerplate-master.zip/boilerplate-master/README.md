melonJS boilerplate
-------------------------------------------------------------------------------

features :
- video autoscaling
- mobile optimized HTML/CSS
- swiping disabled on iOS devices
- debug Panel (if #debug)

-------------------------------------------------------------------------------
Copyright (C) 2011 - 2013, Olivier Biot, Jason Oster
melonJS is licensed under the [MIT License](http://www.opensource.org/licenses/mit-license.php)